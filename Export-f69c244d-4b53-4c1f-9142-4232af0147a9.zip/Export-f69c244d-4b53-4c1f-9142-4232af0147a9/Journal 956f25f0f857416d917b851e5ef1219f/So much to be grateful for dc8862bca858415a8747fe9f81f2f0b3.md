# So much to be grateful for

Created: January 28, 2023 9:55 AM
Tags: Daily

<aside>
💡 **Notion Tip:** Create a new page and select `Daily entry` ****from the list of template options to automatically generate the format below every day.

</aside>

# Intentions

1. 

# Happenings

- 

# Grateful for

1. 

# Action items

- [ ]