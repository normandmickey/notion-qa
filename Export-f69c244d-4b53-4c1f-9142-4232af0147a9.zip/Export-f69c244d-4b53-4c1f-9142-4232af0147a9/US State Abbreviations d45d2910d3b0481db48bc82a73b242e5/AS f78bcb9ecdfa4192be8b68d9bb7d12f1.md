# AS

StateName: American Samoa