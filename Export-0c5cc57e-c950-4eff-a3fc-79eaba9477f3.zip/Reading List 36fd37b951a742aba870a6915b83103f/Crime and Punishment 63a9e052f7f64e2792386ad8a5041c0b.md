# Crime and Punishment

Author: Fyodor Dostoevsky
Completed: November 28, 2022
Link: https://www.goodreads.com/book/show/7144.Crime_and_Punishment
Score: ⭐️⭐️⭐️⭐️⭐️
Status: Done
Type: Book

<aside>
💡 **Notion Tip:** Use this page to keep track of all your notes and highlights. You can also reference other Notion pages by typing the `[[` command. Learn more [here](https://www.notion.so/help/create-links-and-backlinks).

</aside>

![[Penguin Books](https://www.penguinrandomhouse.ca/books/385861/penguin-classics-crime-and-punishment-by-fyodor-dostoevskyoliver-ready/9780141192802)](Crime%20and%20Punishment%2063a9e052f7f64e2792386ad8a5041c0b/Untitled.png)

[Penguin Books](https://www.penguinrandomhouse.ca/books/385861/penguin-classics-crime-and-punishment-by-fyodor-dostoevskyoliver-ready/9780141192802)

**Table of contents**

## Notes

- 

## Key takeaways

- 

## Quotes

> 
> 

## Summary

-