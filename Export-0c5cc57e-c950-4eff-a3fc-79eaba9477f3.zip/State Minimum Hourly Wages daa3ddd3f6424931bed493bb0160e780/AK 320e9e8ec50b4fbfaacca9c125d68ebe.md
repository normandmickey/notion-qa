# AK

Comment: Premium Pay After Designated Hours https://www.dol.gov/agencies/whd/minimum-wage/state#footnote: 
Daily - 8, Weekly - 40
Effective Date: 01/01/2023
MinimumWage: 10.85