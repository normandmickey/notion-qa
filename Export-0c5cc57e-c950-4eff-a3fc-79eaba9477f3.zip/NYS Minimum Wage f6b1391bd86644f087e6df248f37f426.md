# NYS Minimum Wage

New York has two minimum wage rates. 

1. $14.20 per hour for employees in Upstate NY. 
2. $15.00 per hour for employees in New York City, Long Island and Westchester County.