# How to add a new employee?

Date Created: January 29, 2023 7:29 AM
Last Updated: January 30, 2023 7:21 AM

Go to Employee → Add New Employee and clicking on New W2 Employee.

# For email

Go to Employee → Add New Employee

# For Twitter

How should you respond to this question over social media? Draft that here.

# Example questions

Paste links (or screenshots) of the questions that received this response so that new members of your team can see how it's used.