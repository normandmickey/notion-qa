# How to add a pay raise?

Date Created: January 29, 2023 7:27 AM
Last Updated: January 30, 2023 7:05 AM
Tags: Editing

<aside>
💡 Create a new page and select `Saved Response` from the list of template options to automatically generate the format below.

</aside>

# For email

Go to Employee → PaycheckData - Rate

# For Twitter

Draft a version of your response for social media here. Example:

Uh oh! Never fear, if you reset the page using Cmd + R, your images should show up right away. Sorry about that! 😅

# Example questions

Whether you're using Intercom or regular email to handle support queries, you can collect links or screenshots showing how this question has been asked. Example:

![How%20to%20add%20a%20pay%20raise%205377930d0a48441d9c6af7e427760c9b/Screen_Shot_2019-06-18_at_12.54.39_PM.png](How%20to%20add%20a%20pay%20raise%205377930d0a48441d9c6af7e427760c9b/Screen_Shot_2019-06-18_at_12.54.39_PM.png)