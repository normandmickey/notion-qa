# FL

2023 Minimum Hourly Wage: 12
2023 Taxable Wage Base: 7000
StateName: Florida