# AK

2023 Minimum Hourly Wage: 10.85
2023 Taxable Wage Base: 46800
StateName: Alaska