# GA

2023 Minimum Hourly Wage: 7.25
2023 Taxable Wage Base: 9500
StateName: Georgia