# CA

2023 Minimum Hourly Wage: 15.5
2023 Taxable Wage Base: 7000
StateName: California