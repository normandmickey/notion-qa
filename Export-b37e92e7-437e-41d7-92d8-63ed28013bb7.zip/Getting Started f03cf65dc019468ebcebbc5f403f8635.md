# Getting Started

👋 Welcome to Notion!

Here are the basics:

- [x]  Click anywhere and just start typing
- [x]  Hit **/** to see all the types of content you can add - headers, videos, sub pages, etc.
- [ ]  Highlight any text, and use the menu that pops up to **style** *your* ~~writing~~ `however` [you](https://www.notion.so/product) like
- [ ]  See the **⋮⋮** to the left of this checkbox on hover? Click and drag to move this line
- [ ]  Click the **+ New Page** button at the bottom of your sidebar to add a new page
- [ ]  Click **Templates** in your sidebar to get started with pre-built pages
- This is a toggle block. Click the little triangle to see more useful tips!
    - [**notion.com/templates**](https://www.notion.so/templates): More templates built by the Notion community
    - [**notion.com/help**](https://www.notion.so/help): ****Guides and FAQs for everything in Notion
    - [**notion.com/guides**](http://notion.com/guides): Watch videos and read tutorials to become a Notion expert

👉 **Have a question?** Click the `?` at the bottom right for more guides, or to send us a message.