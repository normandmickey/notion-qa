# Sapiens: A Brief History of Humankind

Author: Yuval Noah Harari
Completed: November 1, 2022
Link: https://www.ynharari.com/book/sapiens-2/
Score: ⭐️⭐️⭐️⭐️
Status: Done
Type: Book

<aside>
💡 **Notion Tip:** Use this page to keep track of all your notes and highlights. You can also reference other Notion pages by typing the `[[` command. Learn more [here](https://www.notion.so/help/create-links-and-backlinks).

</aside>

![[Yuval Noah Harari](https://www.ynharari.com/book/sapiens-2/)](Sapiens%20A%20Brief%20History%20of%20Humankind%20f62f4e20330947e29e44b91ded41f807/Untitled.png)

[Yuval Noah Harari](https://www.ynharari.com/book/sapiens-2/)

**Table of contents**

## Notes

- 

## Key takeaways

- 

## Quotes

> 
> 

## Summary

-