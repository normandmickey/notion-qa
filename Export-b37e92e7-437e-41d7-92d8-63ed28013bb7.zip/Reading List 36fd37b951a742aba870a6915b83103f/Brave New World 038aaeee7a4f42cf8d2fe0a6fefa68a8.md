# Brave New World

Author: Aldous Huxley
Completed: November 1, 2022
Link: https://www.penguin.co.uk/books/431950/brave-new-world-by-aldous-huxley/9781784870140
Score: ⭐️⭐️⭐️⭐️⭐️
Status: Done
Type: Book

<aside>
💡 **Notion Tip:** Use this page to keep track of all your notes and highlights. You can also reference other Notion pages by typing the `[[` command. Learn more [here](https://www.notion.so/help/create-links-and-backlinks).

</aside>

![[Penguin Books](https://www.penguin.co.uk/books/431950/brave-new-world-by-aldous-huxley/9781784870140)](Brave%20New%20World%20038aaeee7a4f42cf8d2fe0a6fefa68a8/Untitled.png)

[Penguin Books](https://www.penguin.co.uk/books/431950/brave-new-world-by-aldous-huxley/9781784870140)

**Table of contents**

## Notes

- 

## Key takeaways

- 

## Quotes

> 
> 

## Summary

-