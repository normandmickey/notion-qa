# Who Will Teach Silicon Valley to Be Ethical?

Author: Kara Swisher
Link: https://www.nytimes.com/2018/10/21/opinion/who-will-teach-silicon-valley-to-be-ethical.html
Score: TBD
Status: Not started
Type: Article

<aside>
💡 **Notion Tip:** Use this page to keep track of all your notes and highlights. You can also reference other Notion pages by typing the `[[` command. Learn more [here](https://www.notion.so/help/create-links-and-backlinks).

</aside>

![Cristina Spanò](Who%20Will%20Teach%20Silicon%20Valley%20to%20Be%20Ethical%20fc18bb96773f402e9b43d133f373276a/22swisher-articleLarge.jpg)

Cristina Spanò

**Table of contents**

## Notes

- 

## Key takeaways

- 

## Quotes

> 
> 

## Summary

-