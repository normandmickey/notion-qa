# Netflix: explained

Author: Ezra Klein & Joe Posner
Link: https://www.netflix.com/ca/title/80216752
Score: TBD
Status: In progress
Type: TV Series

<aside>
💡 **Notion Tip:** Use this page to keep track of all your notes and highlights. You can also reference other Notion pages by typing the `[[` command. Learn more [here](https://www.notion.so/help/create-links-and-backlinks).

</aside>

![[Netflix explained](https://www.netflix.com/ca/title/80216752)](Netflix%20explained%209005a3a414af4d0696a6bd678e75749f/explained.png)

[Netflix explained](https://www.netflix.com/ca/title/80216752)

**Table of contents**

## Notes

- 

## Key takeaways

- 

## Quotes

> 
> 

## Summary

-