# VT

2023 Minimum Hourly Wage: 12.55
2023 Taxable Wage Base: 13500
StateName: Vermont