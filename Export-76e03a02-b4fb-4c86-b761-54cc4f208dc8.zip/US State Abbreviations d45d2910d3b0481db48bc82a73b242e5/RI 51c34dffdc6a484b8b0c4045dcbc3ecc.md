# RI

2023 Minimum Hourly Wage: 13
2023 Taxable Wage Base: 24600
StateName: Rhode Island