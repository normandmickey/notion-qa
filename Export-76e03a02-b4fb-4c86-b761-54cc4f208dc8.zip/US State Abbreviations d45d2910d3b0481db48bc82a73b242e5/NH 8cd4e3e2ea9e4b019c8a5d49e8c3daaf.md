# NH

2023 Minimum Hourly Wage: 7.25
2023 Taxable Wage Base: 14000
StateName: New Hampshire